import './App.css';
import Footer from './Component/Footer';
import MainContent from './Component/MainContent';
import NavBar from './Component/NavBar';
import SideBar from './Component/SideBar';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {

  return (
    <div className="App">
      <NavBar />
      <SideBar />
      <MainContent />
      <Footer />
    </div>
  );
}

export default App;
