// import React from "react";



import React, { useState } from "react";

const MainContent = () => {
     const [count, setCount] = useState(0);
     const add = () => {
          setCount(count + 1);
     };
     return (
          <div className=" my-5 m-auto text-center pt-2 " >

               <h3 className="border-bottom  border-secondary pt-1 pb-1"> INCREMENT AND DECREMENT </h3>
               <h4> Count is : {count}</h4>
               <button className="btn btn-info mx-4 mb-3 fw-bold" onClick={add}>
                    {" "}
                    Increment{" "}
               </button>
               <button class="btn btn-info mb-3 fw-bold" onClick={() => setCount(count - 5)}>
                    Decrement
               </button>{" "}
          </div>
     );
};

export default MainContent;
