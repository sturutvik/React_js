import './App.css';
import FormValidation from './Component/FormValidation';
import Reactfrom from './Component/Reactfrom';

function App() {
  return (
    <div>
      <FormValidation />
   <Reactfrom/>
    </div>
  );
}

export default App;
