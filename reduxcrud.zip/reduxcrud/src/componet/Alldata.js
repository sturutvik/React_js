import React, { useState } from 'react'
import { addData, removeData } from '../action';
import { useDispatch, useSelector } from 'react-redux';

export default function Alldata() {
    const uinfo =useSelector((state)=>state.userInfo ||[]);
    const dispatch =useDispatch();
    const[userdata,setUserdata]=useState({
         name: '',
         email: '',
         age:''
    })
    const hchange =(i)=>{
        const {name,value}=i.target;
        setUserdata({...userdata,[name]:value})
    }
const hsubmit =(i)=>{
    i.preventDefault();
    dispatch(addData(userdata));
    setUserdata({
        name: '',
        email: '',
        age:''
    })
}
 const deleteinfo =(id)=>{
    dispatch(removeData(id))
 }

  return (
    <div>

     <form onSubmit={hsubmit}>
        <label>Name</label>
        <input type="text" name="name"  value={userdata.name} onChange={hchange}/><br/>
        <label>Email</label>
        <input type="email" name="email" value={userdata.email} onChange={hchange}/><br/>
        <label>Age</label>
       <input type="number" name="age" value={userdata.age} onChange={hchange}/><br/>
      <button type="submit" value={'savedata'}>submit</button>
     </form>
     <table border={2}>
         <tr>
          <td>Id</td>
          <td>name</td>
          <td>email</td>
          <td>age</td>
          <td>action</td>
         </tr>
         {
          uinfo.map((i,index)=>{
            return(
              <tr>
                <td>{index+1}</td>
                <td>{i.name}</td>
                <td>{i.email}</td>
                <td>{i.age}</td>
                <td><button type='button' onClick={()=>deleteinfo(index)}>Delete</button></td>
              </tr>
            )
          })
         }
     </table>
    </div>
  )
}

