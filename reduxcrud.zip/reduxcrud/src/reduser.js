const initialState = {
    userInfo: [],
};
const useReducer = (state = initialState, action) => {
    switch (action.type) {
        case "ADD_DATA":
            return {
                ...state,
                userInfo: [...state.userInfo, action.payload],
            };
            case"REMOVE_DATA":
            return{
               ...state, userInfo:state.userInfo.filter(
                (i,index)=>index!==action.payload
               )
              
            }
            default:
                return state;
         } 
        
        }
            
            export default   useReducer
