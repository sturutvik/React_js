import   useReducer from "./reduser";
import { createStore } from "redux";

const Store = createStore(useReducer);

export default Store;