import logo from './logo.svg';
import './App.css';
import Alldata from './componet/Alldata';

function App() {
  return (
    <div className="App">
   <Alldata />
    </div>
  );
}

export default App;
