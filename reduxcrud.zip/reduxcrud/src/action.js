export const addData = (value) => ({
    type: "ADD_DATA",
    payload: value,
});
export const removeData = (value) => ({
     type:"REMOVE_DATA",
     payload: value,
})
export const upadatedata = (value) => ({
    type:"UPAD_DATA",
    payload: value,
})