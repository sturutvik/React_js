import React, { Component } from 'react';

class Infromation extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "rutvik sasani",
      age: 20,
      mobileNumber: "1111111",
      email: "rutviksasani1232gmail.com",
    };
  }

  componentDidMount() {
    this.Delay();
  }

  Delay = () => {
    setTimeout(() => {
      this.setState({
        name: "rutvik1",
        age: 21,
        mobileNumber: "7777777777",
        email: "rutvik1gmail.com",
      });
    }, 3000);
  };

  render() {
    return (
      <div>
        <h1>Name: {this.state.name}</h1>
        <p>Age: {this.state.age}</p>
        <p>Mobile Number: {this.state.mobileNumber}</p>
        <p>Email: {this.state.email}</p>
      </div>
    );
  }
}

export default Infromation;