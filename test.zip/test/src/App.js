import logo from './logo.svg';
import './App.css';
 import Q2  from './componet/Q2';
import Infromation from './componet/Infromation';
// import Header from './componet/Header';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
         <h1>rutvik</h1>
          <Q2  />
         {/* <Header /> */}
         <Infromation/>
      </header>
    </div>
  );
}

export default App;
