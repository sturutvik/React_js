import React from "react";
// q-9 //
 const P=() => {
    const student=[
        {
            Name:"Rutvik patel",
            Age:20,
            Address:"Dhandhuka",


        }
    ];
    return(
        <div>
            <h3>Sudents Details..:-</h3>
            {student.map((r)=>{
               return (
                 <div>
                 <h3>Name is:-{r.Name}</h3>
                 <h3>Age is:-{r.Age}</h3>
                 <h3>Address is:-{r.Address}</h3>
                </div>
               )
            })};
        </div>
    )
      
 }
 export default P;