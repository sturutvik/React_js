import React from "react";
const Pr = () => {
    // * q-1 //

    //  circle //

    const circle = (pi = 3.14, r = 40.52) => {
        return pi * r ** 2;
    };

    //   tringle //
    const Triangle = (l, b, h) => {
        return l * b * h;
    };
    //  rectangle //
    const rectangle = (l = 100, w = 40) => l * w;
//    ***************************************   //

//   square //
   let a = [10,20,30,40,50];
   let squares = a.map((numb) => {
   return numb * numb;
});
//  cube 
    let cubes = a.map((num) => {
    return num* num * num;
  });

//   q-3 //
   let b = [10,20,30,40,50];
   let abc = b;

 // q-4 //
    let array = [10,20,30,40,50];
    let numberFind = 40;
//  q-5  //
     let r = [1,2,4,8,10];
     const sum = r.reduce((a, b) => a + b);

   // q-6 //
   let arr = [10, 6, 5, 3, 1];
   let even = [];
   let odd = [];
 
   for (let i = 0; i < arr.length; i++) {
     if (arr[i] % 2 === 0) {
       even.push(arr[i]);
     } else {
       odd.push(arr[i]);
     }
   }
    //    q-7 //
    function isLeapYear(year) {
        if ((year % 4 === 0 && year % 100 !== 0) || year % 400 === 0) {
          return true;
        } else {
          return false;
        }
      }
      const year = 2021;
    //   if (isLeapYear(year)) {
    //     console.log(year + " is a leap year.");
    //   } else {
    //     console.log(year + " is not a leap year.");
    //   }
    //   q-8  //
    let p = [1, 2, 3, 4, 5];
    let q = ["rutvik",  "Umesh", "Jaydip",  "Rachit"];
    let r1 = [...p, ...q];

    return (
        <>
            <div>
                <h3>AREA OF CIRCLE IS...{circle()} </h3>
                <h3>Tringle of ....{Triangle(7, 6, 5)}</h3>
                <h3>Rectangle of...{rectangle()}</h3><hr/>

            </div>
            <div>
                <h3>Square is  Array...:-{squares}</h3>
                <h3>cube is Array...:-{cubes}</h3> <hr/>
            </div>
             <div>
                <h3>Display records...:-{abc}</h3>
             </div>
             <div>
                <h3>Number To Find...:-{numberFind}</h3>
             </div>
             <div>
                <h3>Sum To is...:-{sum}</h3><hr/>
             </div>
             <div>
                <h3>Even number is:-{even}</h3>
                <h3>odd number is:-{odd}</h3><hr/>
            </div>   
            <div>
                <h3>leap year...:-{isLeapYear}</h3>
                
            </div>      
            <div>
                <h3>Marge in...:-{r1}</h3><hr/>
            </div>   

        </>
    )
}

export default Pr;