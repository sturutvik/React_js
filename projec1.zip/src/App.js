import logo from './logo.svg';
import './App.css';
import Pr from './components/pr';
import P from './components/P';

function App() {
  return (
    <div className="App">
        <Pr />
        <P/>
    </div>
  );
}

export default App;
